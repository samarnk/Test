const initState = {
    dataEntryList: [
        { submissionId: '1', identityNo: '1234567890121', firstName:'Stanley',lastName:'Lindsey',policyNo:'D20065721',processType:'REQUEST',activities:['ChangeName','ChangeAddress'] },
        { submissionId: '2', identityNo: '3500200758901', firstName:'Shane',lastName:'Roman',policyNo:'T90023232',processType:'CLAIM',activities:['OPD'] },
        { submissionId: '3', identityNo: '1120890063128', firstName:'Jose',lastName:'Richard',policyNo:'R20332389',processType:'CHANGE',activities:['ChangeICP'] }
    ],

    activityList: [
        { activityId:'1', submissionId: '1', identityNo: '1234567890121', firstName:'Stanley',lastName:'Lindsey',policyNo:'D20065721',processType:'REQUEST',activityName:'Change Name' },
        { activityId:'2', submissionId: '1', identityNo: '1234567890121', firstName:'Stanley',lastName:'Lindsey',policyNo:'D20065721',processType:'REQUEST',activityName:'Change Address' },
        { activityId:'3', submissionId: '2', identityNo: '3500200758901', firstName:'Shane',lastName:'Roman',policyNo:'T90023232',processType:'CLAIM',activityName:'OPD' },
        { activityId:'4',submissionId: '3', identityNo: '1120890063128', firstName:'Jose',lastName:'Richard',policyNo:'R20332389',processType:'REQUEST',activityName:['Change ICP'] }
    ],

    registrationList:[
        {submissionId: '1', identityNo: '1234567890121', firstName:'Stanley',lastName:'Lindsey',processType:'REQUEST',registerActivities:[{policyNo:'D20065721',activity:'CHANGE_NAME'},{policyNo:'D20065721',activity:'UL_FUND_SWITCHING'}]} 
    ],

    processTypesMaster: [ {label:'Request', value:'REQUEST'},
                    {label:'Claim', value:'CLAIM'},
                    {label:'Collection', value:'COLLECTION'},
                    {label:'NewBusiness', value:'NB'}],

    activitiesMaster: [   { processType: 'REQUEST', activity: [
                        {label:'Change Address', value:'CHANGE_ADDRESS'},
                        {label:'Change Name', value:'CHANGE_NAME'},
                        {label:'Change ICP', value:'CHANGE_ICP'},
                        {label:'Change Beneficiary', value:'CHANGE_BENEFICIARY'},
                        {label:'UL Fund Switching',value:'UL_FUND_SWITCHING'}]
                    },
                    { processType: 'CLAIM', activity: [
                        {label:'OPD', value:'OPD'},
                        {label:'FAX Claim', value:'FAX'},
                        {label:'Reimbursement', value:'REIMBURSEMENT'}]
                    },
                    { processType: 'COLLECTION', activity: [
                        {label:'Change Bookbank', value:'CHANGE_BOOKBANK'},
                        {label:'Renewal Payment', value:'RENEW_PAYMENT'}]
                    },
                    { processType: 'NB', activity: [
                        {label:'New Business', value:'NB'}]
                    },
                    
                ]

}

const rootReducer = (state = initState, action) => {
    console.log(action);
    if (action.type === 'SUBMIT_DATAENTRY') {
        let newDataEntry = state.dataentry;
        return {
            ...state,
            dataentry: newDataEntry
        }
    }
    return state;
}





export default rootReducer;