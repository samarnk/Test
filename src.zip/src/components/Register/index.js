import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Form, Button, ButtonToolbar, Container, ButtonGroup, Modal, Row, Col, Table } from 'react-bootstrap';
import axios from 'axios';



class Register extends Component {

    constructor(props) {
        super(props);
        this.state = {
            registration: props.registration,
            processTypeList: props.processTypes,
            activityList: props.activityList
        };
    }


    handleInputChange = (event) => {
        console.log(event.target);
        const target = event.target;
        const value = target.type === 'checkbox' ? target.checked : target.value;
        const name = target.id;
        console.log(event.target.id + '=' + value);
        this.setState({
            [name]: value
        });
        console.log(this.state);
        if (name === 'processType') {
            this.setState({
                activityList: this.props.activityList.find((item) => {
                    return item.processType === this.props.processType;
                })
            });
        }
    }

    processTypeChange(processType) {
        this.setState({
            activityList: this.props.activityList.find((item) => {
                return item.processType === this.props.processType;
            })
        });
    }

    closeSuccessMessage = () => {
        this.setState({ show: false });
    }

    showSuccessMessage = () => {
        this.setState({ show: true });
    }

    formHandler = (data) => {
        console.log('Submission ID = ' + data.submissionId);

        axios.post('https://61bfcc82-6798-4e63-8a3e-69e2837541e0.mock.pstmn.io/api/dataentry', data)
            .then(function (response) {
                console.log(response);
                window.top.close();
                //Perform action based on response
            })
            .catch(function (error) {
                console.log(error);
                //this.showSuccessMessage();
                //Perform action based on error
            });
    }

    render() {
        console.log(this.props.processTypeList);
        const processTypeOptions = this.props.processTypeList.map((item) =>
            <option key={item.value} value={item.value}>{item.label}</option>
        );

        var activityList = this.props.activityList.find((item) => {
            return item.processType === this.props.registration.processType;
        });

        const activityOptions = activityList.activity.map((item, key) =>
        <option key={item.value} value={item.value}>{item.label}</option>
    );

        return (

            <Form className="form-horizontal" onSubmit={this.formHandler(this.state)}>
                <Form.Label><h1>Frontend - Registration</h1></Form.Label>
                <Container>
                    <Row>
                        <Col>
                            <Form.Group controlId="submissionId" >
                                <Form.Label>Submission ID</Form.Label>
                                <Form.Control type="text" value={this.props.registration.submissionId} readOnly></Form.Control>
                            </Form.Group>
                        </Col>
                        <Col>
                            <Form.Group controlId="processType">
                                <Form.Label>Process Type</Form.Label>
                                <Form.Control as="select" value={this.props.registration.processType} readOnly>
                                    {processTypeOptions}
                                </Form.Control>
                            </Form.Group>
                        </Col>
                    </Row>
                    <Row>
                        <Col>
                            <Form.Group controlId="identityNo">
                                <Form.Label>ID Card No. / Passport No.</Form.Label>
                                <Form.Control type="text" value={this.props.registration.identityNo} readOnly />
                            </Form.Group>
                        </Col>
                    </Row>
                    <Row>
                        <Col>
                            <Form.Group controlId="firstName">
                                <Form.Label>First Name</Form.Label>
                                <Form.Control type="text" value={this.props.registration.firstName} readOnly />
                            </Form.Group>
                        </Col>
                        <Col>
                            <Form.Group controlId="lastName">
                                <Form.Label>Last Name</Form.Label>
                                <Form.Control type="text" value={this.props.registration.lastName} readOnly />
                            </Form.Group>
                        </Col>
                    </Row>
                    <Row>
                        <Col>
                            <Table striped bordered hover variant="dark">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Policy No.</th>
                                        <th>Activity</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {this.props.registration.registerActivities.map((registerActivity, i) => {
                                        return (<tr>
                                            <td>{i + 1}</td>
                                            <td><Form.Control type="text" value={registerActivity.policyNo} disabled /></td>
                                            <td><Form.Control as="select" value={registerActivity.activity} >
                                                {activityOptions}
                                            </Form.Control></td>
                                        </tr>)
                                    })}
                                </tbody>
                            </Table>
                        </Col>
                    </Row>
                    <ButtonToolbar className='float-right'>
                        <ButtonGroup className='btn-group mt-2 mr-4'>
                            <Button variant="primary" type="submit">
                                Submit
                            </Button>
                        </ButtonGroup>
                        <ButtonGroup className='btn-group mt-2'>
                            <Button variant="secondary" type="button">
                                Cancel
                                    </Button>
                        </ButtonGroup>
                    </ButtonToolbar>
                </Container>
                <Modal show={this.state.showSuccess} onHide={this.closeSuccessMessage}>
                    <Modal.Header closeButton>
                        <Modal.Title>Modal heading</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>Data entry has been completed!</Modal.Body>
                    <Modal.Footer>
                        <Button variant="secondary" onClick={this.closeSuccessMessage}>
                            Close
                  </Button>
                    </Modal.Footer>
                </Modal>
            </Form>



        );
    }
}

const mapStateToProps = (state, ownProps) => {
    console.log('mapStateToPropss');
    let submissionId = ownProps.match.params.submissionId;
    return {

        registration: state.registrationList.find(registation => registation.submissionId === submissionId),
        processTypeList: state.processTypesMaster,
        activityList: state.activitiesMaster
    }
}



export default connect(mapStateToProps)(Register);