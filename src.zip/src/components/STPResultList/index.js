import React from 'react'
import STPResult from './stpResult.js'
import { Table } from 'react-bootstrap';

const STPResultList = ({ stpResultList }) => (
    <Table striped bordered hover variant="dark" size="sm">
        <thead>
            <tr>
                <th>No.</th>
                <th>Rule Type</th>
                <th>Result</th>
                <th>Message</th>
            </tr>
        </thead>
        <tbody>            
            {
                stpResultList.map((resultItem, i) => {
                    return (
                            <STPResult index={i+1} item={resultItem} />
                    )
                })
            }
        </tbody>
    </Table>
)



export default STPResultList