import React from 'react'


const STPResult = ({ index, item }) => {

    let reultImage = (item.result==='Pass')?'../images/Pass.png':'../images/NotPass.png';

    return (
        <tr>
            <td>{index}</td>
            <td>{item.ruleType}</td>
            <td><img src={reultImage} width="24" height="24"  alt={item.result}/></td>
            <td>{item.message}</td>

        </tr>
    )
}


export default STPResult