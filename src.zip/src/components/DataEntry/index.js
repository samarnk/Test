import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Form, Button, ButtonToolbar, Container, ButtonGroup, Modal } from 'react-bootstrap';
import axios from 'axios';



class DataEntry extends Component {

    constructor(props) {
        super(props);
        this.state = {
            submissionId: props.dataentry.submissionId,
            identityNo: props.dataentry.identityNo,
            firstName: props.dataentry.firstName,
            lastName: props.dataentry.lastName,
            processType: props.dataentry.processType,
            processActivities: props.dataentry.activities,
            processTypeList: props.processTypes,
            activityList: props.activities
        };
    }


    handleInputChange = (event) => {
        console.log(event.target);
        const target = event.target;
        const value = target.type === 'checkbox' ? target.checked : target.value;
        const name = target.id;
        console.log(event.target.id + '=' + value);
        this.setState({
            [name]: value
        });
        console.log(this.state);
        if (name === 'processType') {
            this.setState({
                activityList: this.props.activityList.find((item) => {
                    return item.processType === this.props.processType;
                })
            });
        }
    }

    processTypeChange(processType) {
        this.setState({
            activityList: this.props.activityList.find((item) => {
                return item.processType === this.props.processType;
            })
        });
    }

    closeSuccessMessage = () => {
        this.setState({ show: false });
    }

    showSuccessMessage = () => {
        this.setState({ show: true });
    }

    formHandler = (data) => {
        console.log('Submission ID = ' + data.submissionId);
       
        axios.post('https://61bfcc82-6798-4e63-8a3e-69e2837541e0.mock.pstmn.io/api/dataentry', data)
            .then(function (response) {
                console.log(response);
                window.top.close();
                //Perform action based on response
            })
            .catch(function (error) {
                console.log(error);
                //this.showSuccessMessage();
                //Perform action based on error
            });
    }

    render() {
        console.log(this.props.processTypeList);
        const processTypeOptions = this.props.processTypeList.map((item) =>
            <option key={item.value} value={item.value}>{item.label}</option>
        );

        var activityList = this.props.activityList.find((item) => {
            return item.processType === this.props.dataentry.processType;
        });

        console.log(activityList);

        const activityOptions = activityList.activity.map((item, key) =>
            <option key={item.value} value={item.value}>{item.label}</option>
        );
        return (
            <Container>
                <Form className="form-horizontal" onSubmit={this.formHandler(this.state)}>
                    <Form.Label><h1>Frontend - Data Entry</h1></Form.Label>
                    <Form.Group controlId="submissionId" >
                        <Form.Label>Submission ID</Form.Label>
                        <Form.Control type="text" value={this.state.submissionId} onChange={this.handleInputChange} readOnly></Form.Control>
                    </Form.Group>
                    <Form.Group controlId="identityNo">
                        <Form.Label>ID Card No. / Passport No.</Form.Label>
                        <Form.Control type="text" value={this.state.identityNo} onChange={this.handleInputChange} />
                    </Form.Group>
                    <Form.Group controlId="firstName">
                        <Form.Label>First Name</Form.Label>
                        <Form.Control type="text" value={this.state.firstName} onChange={this.handleInputChange} />
                    </Form.Group>
                    <Form.Group controlId="lastName">
                        <Form.Label>Last Name</Form.Label>
                        <Form.Control type="text" value={this.state.lastName} onChange={this.handleInputChange} />
                    </Form.Group>
                    <Form.Group controlId="processType">
                        <Form.Label>Process Type</Form.Label>
                        <Form.Control as="select" value={this.state.processType} onChange={this.handleInputChange}>
                            {processTypeOptions}
                        </Form.Control>
                    </Form.Group>
                    <Form.Group controlId="activities">
                        <Form.Label>Activity</Form.Label>
                        <Form.Control as="select" multiple value={this.state.activities} onChange={this.handleInputChange}>
                            {activityOptions}
                        </Form.Control>
                    </Form.Group>
                    <ButtonToolbar className='float-right'>
                        <ButtonGroup className='btn-group mt-2 mr-4'>
                            <Button variant="primary" type="submit">
                                Submit
                            </Button>
                        </ButtonGroup>
                        <ButtonGroup className='btn-group mt-2'>
                            <Button variant="secondary" type="button">
                                Cancel
                                    </Button>
                        </ButtonGroup>
                    </ButtonToolbar>
                </Form>
                <Modal show={this.state.showSuccess} onHide={this.closeSuccessMessage}>
                    <Modal.Header closeButton>
                        <Modal.Title>Modal heading</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>Data entry has been completed!</Modal.Body>
                    <Modal.Footer>
                        <Button variant="secondary" onClick={this.closeSuccessMessage}>
                            Close
                  </Button>
                    </Modal.Footer>
                </Modal>
            </Container>

        );
    }
}

const mapStateToProps = (state, ownProps) => {
    console.log('mapStateToPropss');
    let submissionId = ownProps.match.params.submissionId;
    // let dataentry = state.dataEntryList.find(dataentry => dataentry.submissionId === submissionId);
    return {
        // submissionId: dataentry.submissionId,
        // identityNo: dataentry.identityNo,
        // firstName: dataentry.firstName,
        // lastName: dataentry.lastName,
        dataentry: state.dataEntryList.find(dataentry => dataentry.submissionId === submissionId),
        // processType: dataentry.processType,
        // processActivities: dataentry.activities,
        processTypeList: state.processTypesMaster,
        activityList: state.activitiesMaster
    }
}



export default connect(mapStateToProps)(DataEntry);