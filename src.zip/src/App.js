import React from 'react';
import { Route, Switch } from 'react-router-dom'
import DataEntry from './components/DataEntry'
import QualityCheck from './components/QualityCheck'
import Assessment from './components/Assessment'
import Register from './components/Register'

const Home = () => <h1>Home</h1>



function App() {
  return (
    <div className="App container">
      <Switch>
        <Route exact path="/" component={Home} />
        <Route path="/dataentry/:submissionId" component={DataEntry} />
        <Route path="/register/:submissionId" component={Register} />
        <Route path='/qc/:activityId' component={QualityCheck} />
        <Route path='/assessment/:activityId' component={Assessment} />
      </Switch>
    </div>
  );
}

export default App;
