import React from 'react';
import { Route, Switch } from 'react-router-dom'
import DataEntry from './components/DataEntry'
import QualityCheck from './components/QualityCheck'
import Assessment from './components/Assessment'
import Register from './components/Register'
import FundSwitching from './components/FundSwitching'

const Home = () => <h1>Home</h1>



function App() {
  return (
    <div className="App container">
      <Switch>
        <Route exact path="/" component={Home} />
        <Route path="/dataentry/:submissionId" component={DataEntry} />
        <Route path='/qc/:activityId' component={QualityCheck} />
        <Route path='/assessment/:activityId' component={Assessment} />
        <Route path="/register/:submissionId" component={Register} />
        <Route path="/fundswitching/:submissionId" component={FundSwitching} />
      </Switch>
    </div>
  );
}

export default App;
