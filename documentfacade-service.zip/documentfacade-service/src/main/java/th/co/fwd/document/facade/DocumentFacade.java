package th.co.fwd.document.facade;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import th.co.fwd.document.domain.DocumentBO;
import th.co.fwd.document.service.UploadDocumentService;

@Component
public class DocumentFacade {
	
	@Autowired
	UploadDocumentService uploadDocumentService;
	
	public String uploadDocument(DocumentBO document) {
		return uploadDocumentService.uploadDocument(document);
	}

}
