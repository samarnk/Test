package th.co.fwd.document.service;

import org.springframework.stereotype.Service;

import th.co.fwd.document.domain.DocumentBO;

@Service
public class UploadDocumentService {
	
	public String uploadDocument(DocumentBO document) {
		
		return "SUCCESS";
		
	}

}
