package th.co.fwd;


import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ImportResource;

import ch.sbb.esta.openshift.gracefullshutdown.GracefulshutdownSpringApplication;

@SpringBootApplication
@ImportResource({"classpath*:config/*.xml"})
public class Microservice {

	public static void main(String[] args) {
		GracefulshutdownSpringApplication.run(Microservice.class, args);
	}
}
