package th.co.fwd.document.domain;

import java.util.Map;

public class DocumentBO {
	
	
	String fileType;
	
	String fileContent;
	
	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public String getFileContent() {
		return fileContent;
	}

	public void setFileContent(String fileContent) {
		this.fileContent = fileContent;
	}

	public Map getDocumentIndex() {
		return documentIndex;
	}

	public void setDocumentIndex(Map documentIndex) {
		this.documentIndex = documentIndex;
	}

	Map documentIndex;
	

}
