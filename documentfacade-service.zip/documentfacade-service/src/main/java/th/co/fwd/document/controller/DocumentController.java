package th.co.fwd.document.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import th.co.fwd.document.domain.DocumentBO;
import th.co.fwd.document.facade.DocumentFacade;


@RestController
@RequestMapping("documentService")
public class DocumentController {
	
	private static final Logger log = LoggerFactory.getLogger(DocumentController.class);
	
	@Autowired
	private DocumentFacade documentFacade;
	
	@PostMapping(value = "/uploadDocument", consumes = "application/json", produces = "application/json")
	public @ResponseBody String uploadDocument(@RequestBody DocumentBO document) throws Exception {
		
		return documentFacade.uploadDocument(document);
		
	}
}
