package th.co.fwd.auditlog.service;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
@PowerMockIgnore({ "javax.management.*" })
public class AuditLogServiceTest {

	private AuditLogService service = new AuditLogService();

	@Before
	public void setup() {
	}

	@Test
	public void success_case() {

	}
}
