package th.co.fwd.domain;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.*;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.javers.core.Javers;
import org.javers.core.JaversBuilder;
import org.javers.core.diff.Diff;
import org.junit.Test;

import th.co.fwd.auditlog.repository.model.DataEntry;

public class DataEntryTest {

	@Test
	public void testAuditLog() {
		// given
		Javers javers = JaversBuilder.javers().build();
		DataEntry dataEntrty = new DataEntry();
		dataEntrty.setDataEntryId(1234234L);
		dataEntrty.setBatchId(9899L);
		dataEntrty.setDocumentId("POS-0001");
		dataEntrty.setStartEntryDateTime(new Date());
		dataEntrty.setEndEntryDateTime(new Date());
		dataEntrty.setData("{\"PolicyNo\": \"D12342343\"}");

		try {
			DataEntry modufiedDataEntrty = (DataEntry) dataEntrty.clone();
			modufiedDataEntrty.setBatchId(34322L);
			modufiedDataEntrty.setData("SKAJDLKASJDK");
			// when
			Diff diff = javers.compare(dataEntrty, modufiedDataEntrty);

			System.out.println(diff.prettyPrint());

			assertThat(diff.getChanges()).hasSize(2);

		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}

	}

	@Test
	public void testAuditLog_Hashmap() {
		// given
		Javers javers = JaversBuilder.javers().build();
		Map dataEntrty = new HashMap();
		dataEntrty.put("DataEntryID", 1234234L);
		dataEntrty.put("BatchID", 9899L);
		dataEntrty.put("DocumentId", "POS-0001");
		dataEntrty.put("StartEntryDateTime", new Date());
		dataEntrty.put("EndEntryDateTime", new Date());
		dataEntrty.put("Data", "{\"PolicyNo\": \"D12342343\"}");

		Map modufiedDataEntrty = new HashMap();
		modufiedDataEntrty.put("BatchId", 34322L);
		modufiedDataEntrty.put("Data", "SKAJDLKASJDK");
		// when
		Diff diff = javers.compare(dataEntrty, modufiedDataEntrty);

		System.out.println(diff.prettyPrint());

		assertThat(diff.getChanges()).hasSize(2);

	}

}
