package th.co.fwd.auditlog.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import th.co.fwd.auditlog.repository.model.DataEntry;
import th.co.fwd.auditlog.service.DataEntryService;


@RestController
@RequestMapping("/dataentry")
public class DataEntryController {

	
	@Autowired
	private DataEntryService dataEntryService;
	
	
	@PostMapping(value = "/saveDataEntry", produces = "application/json")
	private void saveDataEntry(DataEntry dataEntry) {
		
		dataEntryService.saveDateEntry(dataEntry);
		
	}
	
	
}
