package th.co.fwd.auditlog.repository.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class DataEntry implements Cloneable{
	
	@Id
	@GeneratedValue
	private Long dataEntryId;
	
	
	private Long batchId;
	private String documentId;
	private String data;
	private String userID;
	private Date startEntryDateTime;
	private Date endEntryDateTime;
	
	
	@OneToMany(mappedBy = "dataEntryId")
	private List<DataEntryProperty> dataEntryProperties; 
	
	public Long getDataEntryId() {
		return dataEntryId;
	}
	public void setDataEntryId(Long dataEntryId) {
		this.dataEntryId = dataEntryId;
	}
	public Long getBatchId() {
		return batchId;
	}
	public void setBatchId(Long batchId) {
		this.batchId = batchId;
	}
	public String getDocumentId() {
		return documentId;
	}
	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public Date getStartEntryDateTime() {
		return startEntryDateTime;
	}
	public void setStartEntryDateTime(Date startEntryDateTime) {
		this.startEntryDateTime = startEntryDateTime;
	}
	public Date getEndEntryDateTime() {
		return endEntryDateTime;
	}
	public void setEndEntryDateTime(Date endEntryDateTime) {
		this.endEntryDateTime = endEntryDateTime;
	}
	
	
	
    public List<DataEntryProperty> getDataEntryProperties() {
		return dataEntryProperties;
	}
	public void setDataEntryProperties(List<DataEntryProperty> dataEntryProperties) {
		this.dataEntryProperties = dataEntryProperties;
	}
	public DataEntry clone() throws CloneNotSupportedException {
    	return (DataEntry)super.clone();
    }
	

}
