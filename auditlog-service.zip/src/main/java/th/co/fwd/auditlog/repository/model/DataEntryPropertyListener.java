package th.co.fwd.auditlog.repository.model;

import javax.persistence.EntityManager;
import javax.persistence.PrePersist;
import javax.persistence.PreRemove;
import javax.persistence.PreUpdate;
import javax.transaction.Transactional;

import static javax.transaction.Transactional.TxType.MANDATORY;

import th.co.fwd.auditlog.service.BeanUtil;

public class DataEntryPropertyListener {

	@PrePersist
	public void prePersist(DataEntryProperty target) {
		perform(target, Action.INSERTED);
	}

	@PreUpdate
	public void preUpdate(DataEntryProperty target) {
		perform(target, Action.UPDATED);
	}

	@PreRemove
	public void preRemove(DataEntryProperty target) {
		perform(target, Action.DELETED);
	}

	@Transactional(MANDATORY)
	private void perform(DataEntryProperty target, Action action) {
		EntityManager entityManager = BeanUtil.getBean(EntityManager.class);
//		entityManager.persist(new DataEntryPropertyAudit(target, action));
	}

}
