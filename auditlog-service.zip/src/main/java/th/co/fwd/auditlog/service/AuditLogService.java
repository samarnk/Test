package th.co.fwd.auditlog.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import th.co.fwd.base.domain.AbstractBO;

@Service
public class AuditLogService {

	private static final Logger log = LoggerFactory.getLogger(AuditLogService.class);

	public AbstractBO method(AbstractBO input) {
		return input;
	}
}
