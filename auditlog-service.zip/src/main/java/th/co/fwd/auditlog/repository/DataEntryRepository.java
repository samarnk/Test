package th.co.fwd.auditlog.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import th.co.fwd.auditlog.repository.model.DataEntry;

public interface DataEntryRepository extends JpaRepository<DataEntry, Long>{
	
	
	
}
