package th.co.fwd.auditlog.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import th.co.fwd.auditlog.repository.DataEntryRepository;
import th.co.fwd.auditlog.repository.model.DataEntry;

@Service
public class DataEntryService {
	
	private static final Logger log = LoggerFactory.getLogger(DataEntryService.class);
	
	private DataEntryRepository dataEntryRepository; 
	
	
	public DataEntry getDataEntry(Long dataEntryId) {
		
		return dataEntryRepository.getOne(dataEntryId);
		
	}
	
	public void saveDateEntry(DataEntry dataEntry) {
		dataEntryRepository.save(dataEntry);
	}
	
	
}
