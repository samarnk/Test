package th.co.fwd.auditlog.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import th.co.fwd.auditlog.facade.AuditLogFacade;
import th.co.fwd.base.domain.AbstractBO;

@RestController
@RequestMapping("/auditlogService")
public class AuditLogController {
	

	@Autowired
	private AuditLogFacade auditlogFacade;

	@PostMapping( value = "/method",consumes="application/json", produces = "application/json" ) 
	public @ResponseBody AbstractBO method(@RequestBody AbstractBO input) throws Exception {
		return input;
	}
}
