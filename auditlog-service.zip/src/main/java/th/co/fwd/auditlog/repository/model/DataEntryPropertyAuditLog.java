package th.co.fwd.auditlog.repository.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreRemove;
import javax.persistence.PreUpdate;

@Entity
public class DataEntryPropertyAuditLog {
	
	@Id
	@GeneratedValue
	private Long dataEntryPropertyId;
	
	@ManyToOne
//	@JoinColumn(name = "DateEntryId", foreignKey = @ForeignKey(name = "FK_DateEntryProperty_Da"))
	private Long dataEntryId;
	
	private String property;
	private String value;
	private String createdBy;
	private Date createdDateTime;
	private String updatedBy;
	private Date updatedDateTime;

	public Long getDataEntryPropertyId() {
		return dataEntryPropertyId;
	}

	public void setDataEntryPropertyId(Long dataEntryPropertyId) {
		this.dataEntryPropertyId = dataEntryPropertyId;
	}

	public Long getDataEntryId() {
		return dataEntryId;
	}

	public void setDataEntryId(Long dataEntryId) {
		this.dataEntryId = dataEntryId;
	}

	public String getProperty() {
		return property;
	}

	public void setProperty(String property) {
		this.property = property;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDateTime() {
		return createdDateTime;
	}

	public void setCreatedDateTime(Date createdDateTime) {
		this.createdDateTime = createdDateTime;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDateTime() {
		return updatedDateTime;
	}

	public void setUpdatedDateTime(Date updatedDateTime) {
		this.updatedDateTime = updatedDateTime;
	}

	@PrePersist
	public void prePersist() {

	}

	@PreUpdate
	public void preUpdate() {
		
	}

	@PreRemove
	public void preRemove() {
		
	}

}
