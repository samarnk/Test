package th.co.fwd.auditlog.facade;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import th.co.fwd.auditlog.service.AuditLogService;
import th.co.fwd.base.domain.AbstractBO;

@Service
public class AuditLogFacade {

    /*
     * Beans
     */
	@Autowired
	private AuditLogService auditlogService;
	
    /*
     * Facade methods
     */	
	public AbstractBO method(AbstractBO input) {
		return input;
	}
}
