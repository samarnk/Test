import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Form, Button, ButtonToolbar, Container, Row, Col, ButtonGroup, Dropdown, DropdownButton } from 'react-bootstrap'


class Assessment extends Component {

    constructor(props) {
        super(props);
        this.state = {
            activityId: props.activity.activityId,
            submissionId: props.activity.submissionId,
            identityNo: props.activity.identityNo,
            firstName: props.activity.firstName,
            lastName: props.activity.lastName,
            processType: props.activity.processType,
            activity: props.activity.activityName,
        };
    }


    handleInputChange = (event) => {
        console.log(event.target);
        const target = event.target;
        const value = target.type === 'checkbox' ? target.checked : target.value;
        const name = target.id;
        console.log(event.target.id + '=' + value);
        this.setState({
            [name]: value
        });
        console.log(this.state);
    }


    render() {

        return (

            <Form className="form-horizontal">
                <Form.Label><h1>Frontend - Activity Assessment</h1></Form.Label>
                <Container>
                    <Row>
                        <Col>
                            <Form.Group controlId="activityId" >
                                <Form.Label>Activity ID</Form.Label>
                                <Form.Control type="text" value={this.state.activityId} onChange={this.handleInputChange} disabled='true'></Form.Control>
                            </Form.Group>
                        </Col>
                        <Col>
                            <Form.Group controlId="submissionId" >
                                <Form.Label>Submission ID</Form.Label>
                                <Form.Control type="text" value={this.state.submissionId} onChange={this.handleInputChange} disabled='true'></Form.Control>
                            </Form.Group>
                        </Col>
                    </Row>

                    <Form.Group controlId="identityNo">
                        <Form.Label>ID Card No. / Passport No.</Form.Label>
                        <Form.Control type="text" value={this.state.identityNo} onChange={this.handleInputChange} disabled='true' />
                    </Form.Group>
                    <Row>
                        <Col>
                            <Form.Group controlId="firstName">
                                <Form.Label>First Name</Form.Label>
                                <Form.Control type="text" value={this.state.firstName} onChange={this.handleInputChange} disabled='true' />
                            </Form.Group>
                        </Col>
                        <Col>
                            <Form.Group controlId="lastName">
                                <Form.Label>Last Name</Form.Label>
                                <Form.Control type="text" value={this.state.lastName} onChange={this.handleInputChange} disabled='true' />
                            </Form.Group>
                        </Col>
                    </Row>
                    <Row>
                        <Col>
                            <Form.Group controlId="processType">
                                <Form.Label>Process Type</Form.Label>
                                <Form.Control type="text" value={this.state.processType} onChange={this.handleInputChange} disabled='true' />
                            </Form.Group>
                        </Col>
                        <Col>
                            <Form.Group controlId="activityName">
                                <Form.Label>Activity</Form.Label>
                                <Form.Control type="text" value={this.state.activity} onChange={this.handleInputChange} disabled='true' />
                            </Form.Group>
                        </Col>
                    </Row>
                    <div class="panel panel-default">
                        <div class="panel-heading">Change Name</div>
                        <div class="panel-body">
                            <Form.Group controlId="field1">
                                <Form.Label>Field 1</Form.Label>
                                <Form.Control type="text" disabled='true' />
                            </Form.Group>
                            <Form.Group controlId="field2">
                                <Form.Label>Field 2</Form.Label>
                                <Form.Control type="text" disabled='true' />
                            </Form.Group>
                        </div>
                    </div>
                    <ButtonToolbar className='float-right'>
                        <ButtonGroup className='btn-group mt-2 mr-4'>
                            <DropdownButton as={ButtonGroup} title="Decision" id="bg-nested-dropdown">
                                <Dropdown.Item eventKey="1">Approve</Dropdown.Item>
                                <Dropdown.Item eventKey="2">Pending</Dropdown.Item>
                            </DropdownButton>
                        </ButtonGroup>
                        <ButtonGroup className='btn-group mt-2'>
                            <Button variant="secondary" type="button">
                                Cancel
                                    </Button>
                        </ButtonGroup>
                    </ButtonToolbar>
                </Container>
            </Form>

        );
    }
}

const mapStateToProps = (state, ownProps) => {
    console.log('mapStateToPropss');
    let activityId = ownProps.match.params.activityId;

    return {
        activity: state.activityList.find(activity => activity.activityId === activityId),
        processTypeList: state.processTypes,
        activityList: state.activities
    }
}



export default connect(mapStateToProps)(Assessment);