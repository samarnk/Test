import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {DocumentImportComponent} from './document-import/document-import.component';


const routes: Routes = [{
  path: 'document/import',
  component: DocumentImportComponent
}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
