import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { HttpClientModule   } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';


import { DocumentImportComponent } from './document-import/document-import.component';
import { SlimLoadingBarModule } from 'ng2-slim-loading-bar';
import { ProgressBarComponent } from './progress-bar/progress-bar.component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { DragDropFileDirective } from './directives/dragdrop-file.directive';
import { FileSizePipe } from './pipes/file-size.pipe';



@NgModule({
  declarations: [
    AppComponent,
    DocumentImportComponent,    
    ProgressBarComponent,
    DragDropFileDirective,
    FileSizePipe
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    NgbModule,
    SlimLoadingBarModule,
    HttpClientModule,
    NgMultiSelectDropDownModule.forRoot()
  ],
  providers: [],
  bootstrap: [AppComponent],
  
})
export class AppModule { }
