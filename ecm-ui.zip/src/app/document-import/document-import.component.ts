import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { HttpEventType, HttpClient } from '@angular/common/http';

interface Alert {
  type: string;
  message: string;
}


@Component({
  selector: 'app-document-import',
  templateUrl: './document-import.component.html',
  styleUrls: ['./document-import.component.css']
})
export class DocumentImportComponent implements OnInit {


  alert: Alert;


  progress: number = 0;

  importDocumentForm: FormGroup;

  submitted: boolean = false;

  //Process Type
  processTypes = [];
  processTypeDropdownSettings = {};
  processTypeSelectedItems = [];

  //Form Name
  formNames = [];
  formNameDropdownSettings = {};
  formNameSelectedItems = [];

  //documentId
  documentId: string;

  constructor(private http: HttpClient) { }

  ngOnInit() {

    this.importDocumentForm = new FormGroup({
      uploadFile: new FormControl(null, Validators.required),
      processType: new FormControl([], Validators.required),
      formName: new FormControl(null, Validators.required),
      documentId: new FormControl(null, Validators.required),
      category: new FormControl(null, Validators.required),
      policyNo: new FormControl(null),
      identityNo: new FormControl(null),
      firstName: new FormControl(null),
      lastName: new FormControl(null),

    });

    this.processTypes = [
      { item_id: 'NB', item_text: 'New Business' },
      { item_id: 'CHANGE', item_text: 'Change' },
      { item_id: 'DEADCLAIM', item_text: 'Dead Claim' },
      { item_id: 'LIVINGCLAIM', item_text: 'Living Claim' },
      { item_id: 'COMPLIANT', item_text: 'Compliant' }

    ];
    this.processTypeDropdownSettings = {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      itemsShowLimit: 10,
      allowSearchFilter: true
    };

    this.formNames = [
      { item_id: 'A0001', item_text: 'ใบคำขอ', category: "Application" },
      { item_id: 'A0002', item_text: 'บัตรประจำตัวประชาชน', category: "Identity" },
      { item_id: 'O001', item_text: 'อื่นๆ', category: "Other" }

    ];

    this.formNameDropdownSettings = {
      singleSelection: true,
      idField: 'item_id',
      textField: 'item_text',
      itemsShowLimit: 10,
      allowSearchFilter: true
    };

  }

  // convenience getter for easy access to form fields
  get f() { return this.importDocumentForm.controls; }

  onItemSelectProcessType(item: any) {
    console.log(item);
  }

  onItemSelectFormName(item: any) {
    console.log(item);
    this.importDocumentForm.controls.documentId.setValue(item.item_id);
    this.importDocumentForm.controls.category.setValue(this.formNames.find((i) => i.item_id = item.item_id).category);

  }

  onItemDeSelectFormName(item: any) {
    this.importDocumentForm.controls.documentId.setValue(null);
    this.importDocumentForm.controls.category.setValue(null);
  }
  onSelectAll(items: any) {
    console.log(items);
  }

  closeAlert() {
    this.alert= null;
  }

  onFileChange(event) {
    let reader = new FileReader();
    if (event.target.files && event.target.files.length > 0) {
      let file = event.target.files[0];
      reader.readAsDataURL(file);
      reader.onload = () => {
        this.importDocumentForm.get('uploadFile').setValue({
          filename: file.name,
          filetype: file.type,
          filesize: file.size,
          value: reader.result
        })
      };
      console.log(this.importDocumentForm.get('uploadFile'));
    }
  }

  onSubmit() {
    console.log(this.importDocumentForm.invalid);

    this.submitted = true;
    this.alert = null;
    if (this.importDocumentForm.invalid) {
      console.log(this.f.uploadFile);
      return;
    }
    this.http.post('http://localhost:8901/ecm-bridge/uploadDocument1', this.importDocumentForm.value, {
      reportProgress: false,
      //observe: 'events'
    }).subscribe(      
      data => {
        console.log("Data", data);
        this.submitted = false;
        this.importDocumentForm.reset();
        this.alert = {
          type: 'success',
          message: 'Uploaded document successfully.',
        }
      },  
      error => {
        console.log("Error", error);
        this.alert = {
          type: 'danger',
          message: 'Upload document failed!, ' + error.message,
        }


      },
      
    );



  }


}



export function toFormData<T>(formValue: T) {
  const formData = new FormData();

  for (const key of Object.keys(formValue)) {
    const value = formValue[key];
    formData.append(key, value);
  }

  return formData;
}